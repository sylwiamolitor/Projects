/**
 *
 * Classes in model.
 * @since 1.0
 * @author Sylwia Molitor
 * @version 5.0
 */
package pl.polsl.model;