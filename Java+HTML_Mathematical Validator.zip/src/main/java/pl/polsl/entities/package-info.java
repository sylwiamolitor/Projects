
/**
 * Classes in entities
 *  @since 6.0
 *  @author Sylwia Molitor
 *  @version 1.0
 */
package pl.polsl.entities;